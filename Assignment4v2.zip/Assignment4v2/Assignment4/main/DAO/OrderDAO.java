package DAO;

public interface OrderDAO {

}
