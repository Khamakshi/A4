package DAO;

public interface ProductDAO {

}
