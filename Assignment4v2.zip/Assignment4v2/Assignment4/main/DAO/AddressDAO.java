package DAO;

public interface AddressDAO {
    

}
