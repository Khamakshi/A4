package DAO;

import Objects.Customer;

public interface CustomerDAO {
    
    public Customer createCustomer (Customer customer);
    public Customer readCustomer (int id);
    public void updateCustomer (Customer customer);
    public void deleteCustomer (int id);
    

}
