package DAOImp;
import java.lang.invoke.MethodHandles;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.Serializable;
import java.sql.SQLException;
import java.sql.Statement;
import javax.annotation.Resource;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import DAO.CustomerDAO;
import Objects.Customer;

public class CustomerDAOImp implements Serializable, CustomerDAO{
    private static final Logger logger = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Resource(name = "jdbc/shopingCartDb")
    protected DataSource shopingCartDb;
    Connection con = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    protected Customer customer;

    @Override
    public Customer createCustomer(Customer customer) {
        try {
            con = shopingCartDb.getConnection();
            pstmt = con.prepareStatement(
                    "INSERT INTO CUSTOMER (Name,Address_ID) VALUES (?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, customer.getName());
            pstmt.setInt(2, customer.getId());
            pstmt.execute();
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int id = generatedKeys.getInt(1);
                customer.setId(id);
            }
        }
        catch (SQLException e) {
            logger.error("something went wrong accessing Customer table", e);
        }

        finally {
            try { rs.close(); } catch (Exception e) { }
            try { pstmt.close(); } catch (Exception e) { }
            try { con.close(); } catch (Exception e) { }

        }

        return customer;
    }

    @Override
    public Customer readCustomer(int id) {
        try {
            con = shopingCartDb.getConnection();
            pstmt = con.prepareStatement("SELECT * FROM CUSTOMER WHERE id=?");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Customer newCustomer = new Customer();
                newCustomer.setId(rs.getInt("id"));
                newCustomer.setName(rs.getString("Name"));
                newCustomer.setAddressID(rs.getInt("Address_ID"));
                this.customer=newCustomer;
            }
        }
        catch (SQLException e) {
            logger.error("something went wrong when reading from customer table", e);
        }
        finally {
            try { rs.close(); } catch (Exception e) { }
            try { pstmt.close(); } catch (Exception e) { }
            try { con.close(); } catch (Exception e) { }
        }
        
        return customer;
    }
    

    @Override
    public void updateCustomer(Customer customer) {
        logger.info("updating customer");
        try {
            con = shopingCartDb.getConnection();
            pstmt = con.prepareStatement(
                    "UPDATE CUSTOMER SET Name =?,Address_ID=? WHERE id=?");
            pstmt.setString(1, customer.getName());
            pstmt.setInt(2, customer.getAddressID());
            pstmt.execute();
        }
        catch (SQLException e) {
            logger.error("something went wrong updating Customer table", e);
        }
     
        finally {
             try { rs.close(); } catch (Exception e) { /* ignored */ }
             try { pstmt.close(); } catch (Exception e) { /* ignored */ }
             try { con.close(); } catch (Exception e) { /* ignored */ }

        }

    }

    @Override
    public void deleteCustomer(int id) {
        try {
            con = shopingCartDb.getConnection();
            pstmt = con.prepareStatement(
                    "DELETE FROM CUSTOMER WHERE id=?");
            pstmt.setInt(1, id);
            pstmt.execute();
            pstmt.close();

        }
        catch (SQLException e) {
            logger.error("something went wrong deleting from customer table", e);
        }
        finally {
            try { rs.close(); } catch (Exception e) { }
            try { pstmt.close(); } catch (Exception e) { }
            try { con.close(); } catch (Exception e) { }

        }

    }

}
