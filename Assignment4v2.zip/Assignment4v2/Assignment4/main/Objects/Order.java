package Objects;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ORDER")
public class Order extends Modelbase{
    
    @Id
    @Column(name="ID")
    private static final long serialVersionUID = 1L;
    
    @Column(name="COST")
    protected double cost;
    
    @OneToOne
    @JoinColumn(name="CUSTOMER_ID", referencedColumnName = "ID")
    protected Customer Customer;
    
    @ManyToMany(cascade=CascadeType.ALL)
    @JoinTable(name="ORDER_PRODUCT", joinColumns= {@JoinColumn(referencedColumnName="ID")}, inverseJoinColumns= {@JoinColumn(referencedColumnName="ID")})
    private Set<Product> Products;

    public Customer getCustomer() {
        return Customer;
    }
    
    public double getCost() {
        return cost;
    }
    public void setCost(double cost) {
        this.cost = cost;
    }
    
    public void setCustomer(Customer customer) {
        Customer = customer;
    }

    public Set<Product> getProducts() {
        return Products;
    }

    public void setProducts(Set<Product> products) {
        Products = products;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }
    
}
