package Objects;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCTS")
public class Product {
    
    @Id
    @Column(name="ID")
    private static final long serialVersionUID = 1L;
    
    @Column(name="item")
    protected String item;
    
    @Column(name="Price")
    protected double price;

    @ManyToMany(mappedBy="Products")
    private Set<Order> Orders;

    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }

    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    public Set<Order> getOrders() {
        return Orders;
    }
    public void setOrders(Set<Order> orders) {
        Orders = orders;
    }

}
