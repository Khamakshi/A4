package Objects;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER")
public class Customer extends Modelbase{
    
    @Id
    @Column(name="ID")
    private static final long serialVersionUID = 1L;
    
    @Column(name="NAME")
    protected String Name;
    
    @OneToOne
    @JoinColumn(name="ADDRESS_ID", referencedColumnName = "ADDRESS_ID")
    protected int AddressID;

    public Customer() {
        super();
    }
    public int getCust_ID() {
        return this.id;
    }
    public int getAddressID() {
        return AddressID;
    }
    public void setAddressID(int id) {
        this.AddressID=id;
    }

    public String getName() {
        return Name;
    }
    public void setName(String name) {
        this.Name=name;
    }
}
